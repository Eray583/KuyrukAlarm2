package com.eray.kuyrukalarm

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : ComponentActivity() {

    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var motionText: TextView
    private lateinit var sensitivityText: TextView
    private lateinit var sensitivity: SeekBar
    private lateinit var startButton: Button

    private val executor = Executors.newSingleThreadExecutor()
    private var analyzing = false
    private var previous: ByteArray? = null
    private var movementStart = 0L
    private var alarmLockUntil = 0L
    private var tts: TextToSpeech? = null
    private var tone: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        motionText = findViewById(R.id.motionText)
        sensitivityText = findViewById(R.id.sensitivityText)
        sensitivity = findViewById(R.id.sensitivity)
        startButton = findViewById(R.id.startButton)

        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setSpeechRate(0.9f)
            }
        }

        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)

        sensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val value = (p + 5).coerceIn(5, 60)
                sensitivityText.text = "Hassasiyet: $value — daha düşük = daha hassas"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.testButton).setOnClickListener { alarm() }

        startButton.setOnClickListener {
            analyzing = !analyzing
            previous = null
            movementStart = 0L
            startButton.text = if (analyzing) "TAKİBİ DURDUR" else "TAKİBİ BAŞLAT"
            status.text = if (analyzing) "🟢 Araç takip ediliyor..." else "🟡 Takip durduruldu"
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        } else {
            startCamera()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build()
            previewUseCase.setSurfaceProvider(preview.surfaceProvider)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()

            analysis.setAnalyzer(executor) { image -> analyze(image) }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                previewUseCase,
                analysis
            )
            status.text = "🟡 Hazır — önce telefonu sabitle"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(image: ImageProxy) {
        try {
            val y = image.planes[0].buffer
            val w = image.width
            val h = image.height

            // Orta bölüm: yeşil kutuyla yaklaşık aynı alan.
            val left = (w * 0.18).toInt()
            val right = (w * 0.82).toInt()
            val top = (h * 0.30).toInt()
            val bottom = (h * 0.68).toInt()

            val current = sampleY(y, w, h, left, top, right, bottom)
            val old = previous

            if (old != null && old.size == current.size) {
                var sum = 0L
                var i = 0
                while (i < current.size) {
                    sum += abs(current[i].toInt() - old[i].toInt()])
                    i++
                }
                val score = sum.toDouble() / current.size
                runOnUiThread { motionText.text = "Hareket: %.1f".format(score) }

                val threshold = (sensitivity.progress + 5).coerceIn(5, 60)

                // Kısa titreşimleri değil, sürekli/belirgin hareketi arıyoruz.
                // Fiziksel olarak "tam 1–2 metre" ölçmek kamera geometrisi olmadan
                // mümkün değildir; bu eşik güçlü araç hareketine göre kalibre edilir.
                if (analyzing && score >= threshold) {
                    if (movementStart == 0L) movementStart = SystemClock.elapsedRealtime()
                    val held = SystemClock.elapsedRealtime() - movementStart

                    // En az 1.0 saniye sürekli hareket + 5 saniye alarm kilidi.
                    if (held >= 1000L && SystemClock.elapsedRealtime() > alarmLockUntil) {
                        alarm()
                        alarmLockUntil = SystemClock.elapsedRealtime() + 5000L
                        movementStart = 0L
                    }
                } else {
                    movementStart = 0L
                }
            }

            previous = current
        } finally {
            image.close()
        }
    }

    private fun sampleY(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int
    ): ByteArray {
        val all = ByteArray(buffer.remaining())
        buffer.get(all)
        val out = ArrayList<Byte>(5000)
        val stepX = ((right - left) / 32).coerceAtLeast(1)
        val stepY = ((bottom - top) / 20).coerceAtLeast(1)

        var yy = top
        while (yy < bottom) {
            var xx = left
            while (xx < right) {
                val idx = yy * width + xx
                if (idx in all.indices) out.add(all[idx])
                xx += stepX
            }
            yy += stepY
        }
        return out.toByteArray()
    }

    private fun alarm() {
        runOnUiThread {
            status.text = "🚨 ÖNDEKİ ARAÇ HAREKET ETTİ!"
        }

        try {
            val vib = if (android.os.Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 900), -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(longArrayOf(0, 500, 200, 500, 200, 900), -1)
            }
        } catch (_: Exception) {}

        try {
            tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500)
        } catch (_: Exception) {}

        try {
            tts?.speak(
                "Öndeki araç hareket etti. İlerle.",
                TextToSpeech.QUEUE_FLUSH,
                null,
                "queue_alarm"
            )
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        tts?.shutdown()
        tone?.release()
    }
}
